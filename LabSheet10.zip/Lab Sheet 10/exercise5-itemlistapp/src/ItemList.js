import React, { useState } from "react";

function ItemList() {
  const [items, setItems] = useState([
    { id: 1, name: "Notebook" },
    { id: 2, name: "Pen" },
    { id: 3, name: "Bag" }
  ]);

  const [newItem, setNewItem] = useState("");

  const addItem = () => {
    if (newItem.trim() === "") {
      return;
    }

    const item = {
      id: Date.now(),
      name: newItem
    };

    setItems([...items, item]);
    setNewItem("");
  };

  const removeItem = (id) => {
    const updatedItems = items.filter((item) => item.id !== id);
    setItems(updatedItems);
  };

  return (
    <div className="list-box">
      <div className="input-section">
        <input
          type="text"
          placeholder="Enter item name"
          value={newItem}
          onChange={(event) => setNewItem(event.target.value)}
        />
        <button onClick={addItem}>Add Item</button>
      </div>

      {items.length === 0 ? (
        <p className="empty-message">No items available</p>
      ) : (
        <ul>
          {items.map((item) => (
            <li key={item.id} className="list-item">
              <span>{item.name}</span>
              <button onClick={() => removeItem(item.id)}>Remove</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default ItemList;