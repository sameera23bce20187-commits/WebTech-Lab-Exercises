import React from "react";
import DataFetch from "./DataFetch";

function App() {
  return (
    <div className="container">
      <h1>API Data Fetch Example</h1>
      <DataFetch />
    </div>
  );
}

export default App;