import React from "react";
import UserForm from "./UserForm";

function App() {
  return (
    <div className="container">
      <h1>User Information Form</h1>
      <UserForm />
    </div>
  );
}

export default App;