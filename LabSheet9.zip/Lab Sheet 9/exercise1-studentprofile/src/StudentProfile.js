import React from "react";

function StudentProfile() {
  const name = "Harshitha Manne";
  const department = "Computer Science";
  const year = "3rd Year";
  const section = "A";

  return (
    <div style={{
      padding: "20px",
      fontFamily: "Arial",
      backgroundColor: "grey",
      width: "300px",
      margin: "50px auto",
      borderRadius: "10px",
      boxShadow: "0 0 10px rgba(0,0,0,0.7)"
    }}>
      <h2>Student Profile</h2>

      <p><strong>Name:</strong> {name}</p>
      <p><strong>Department:</strong> {department}</p>
      <p><strong>Year:</strong> {year}</p>
      <p><strong>Section:</strong> {section}</p>
    </div>
  );
}

export default StudentProfile;