import React from "react";
import StudentCard from "./StudentCard";

function App() {
  return (
    <div className="container">
      <h1>Student Cards</h1>

      <div className="card-container">
        <StudentCard
          name="Harshitha Manne"
          department="Computer Science"
          marks="92"
        />

        <StudentCard
          name="Anjali Reddy"
          department="Electronics"
          marks="88"
        />

        <StudentCard
          name="Rahul Kumar"
          department="Mechanical"
          marks="85"
        />

        <StudentCard
          name="Sneha Sharma"
          department="Information Technology"
          marks="95"
        />
      </div>
    </div>
  );
}

export default App;