import React from "react";
import Counter from "./Counter";

function App() {
  return (
    <div className="container">
      <h1>Counter Application</h1>
      <Counter />
    </div>
  );
}

export default App;